Sitepackage for the project "Ngs Default Template"
==============================================================

Add some explanation here.
