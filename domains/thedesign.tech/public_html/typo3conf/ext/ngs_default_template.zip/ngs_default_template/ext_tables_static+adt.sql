#
# Add Static SQL tables
#
