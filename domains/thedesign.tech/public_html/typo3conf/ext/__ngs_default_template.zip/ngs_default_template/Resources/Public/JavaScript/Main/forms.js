/**
 * Forms
 */
var Forms = {

    init: function () {
        this.initJoinUsDubai();
        this.initDropzone();
    },

    initJoinUsDubai: function (){
        $('.dubai .f_join-us').on('click', function (){
            console.log(123);
            $('.f_join-us-dubai-container').show();
        });
    },
    
    initDropzone: function (){
        $('.js-file-dropzone').on('dragover', function() {
            $(this).addClass('hover');
        });

        $('.js-file-dropzone').on('dragleave', function() {
            $(this).removeClass('hover');
        });

        $('.js-file-dropzone input').on('change', function(e) {
            var file = this.files[0];

            $('.js-file-dropzone').removeClass('hover');

            if (this.accept && $.inArray(file.type, this.accept.split(/, ?/)) == -1) {
                return alert('File type not allowed.');
            }

            $('.js-file-dropzone').addClass('dropped');
            $('.js-file-dropzone img').remove();

            if ((/^image\/(gif|png|jpeg)$/i).test(file.type)) {
                var reader = new FileReader(file);

                reader.readAsDataURL(file);

                reader.onload = function(e) {
                    var data = e.target.result,
                        $img = $('<img />').attr('src', data).fadeIn();

                    $('.js-file-dropzone div').html($img);
                };
            } else {
                var ext = file.name.split('.').pop();

                $('.js-file-dropzone div').html(ext);
            }
        });
    }
};
