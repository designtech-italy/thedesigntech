<?php
defined('TYPO3') or die('Access denied.');