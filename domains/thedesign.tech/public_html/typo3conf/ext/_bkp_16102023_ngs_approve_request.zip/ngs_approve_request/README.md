Sitepackage for the project "Ngs Approve Request"
==============================================================

Add some explanation here.
for using this plugin need to remove cacheHash   in [AdditionalConfiguration.php]
$GLOBALS['TYPO3_CONF_VARS']['FE']['cacheHash']['excludedParameters'] = ['ngsapproverequest_request[booking]','ngsapproverequest_request[event]'];

