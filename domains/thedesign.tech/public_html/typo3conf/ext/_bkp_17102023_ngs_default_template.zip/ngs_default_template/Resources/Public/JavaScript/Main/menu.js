/**
 * Menu
 */
var Menu = {

    init: function () {
        this.joinUsFormPopup();
        this.joinUsDesignFormPopup();
        this.registerMenuLinkEvents();
    },

    registerMenuLinkEvents: function () {
        let self = this;
        let headerMenu = $('.f_header-main');
        let $topHeaderEl = headerMenu.find('.f_header-box');

        $topHeaderEl.find('.f_noLink').on('click', function () {
            let targetContentUid = $(this).attr('data-target-uid');
            let $targetContentEl = $('#c' + targetContentUid);
            if ($targetContentEl.length) {
                let scrollPos = $targetContentEl.offset().top - $topHeaderEl.outerHeight();
                Helper._scrollToElem(scrollPos);
                return false;
            }
        });
    },

    joinUsFormPopup: function () {
        let joinUsContainer = $('.f_join-us-container');

        $('.f_join-us').on('click', function () {
            joinUsContainer.toggleClass("is_active");
        });
        $('.f_join-us-icon').on('click', function () {
            joinUsContainer.toggleClass("is_active");
        });
    },

    joinUsDesignFormPopup: function () {
        let joinUsDesignContainer = $('.f_join-us-design-container');

        $('.f_join-us-design').on('click', function () {
            joinUsDesignContainer.toggleClass("is_active");
        });
        $('.f_join-us-design-icon').on('click', function () {
            joinUsDesignContainer.toggleClass("is_active");
        });
    },
};
